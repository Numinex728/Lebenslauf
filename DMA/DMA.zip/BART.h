int init_UART(void);
int UART_learns_to_talk(int isInit, char* data, int length);
void UART_learns_to_listen(char* data);
