#include <stdint.h>

void init_adc(void);
uint16_t konvertiere(uint16_t kanal);
