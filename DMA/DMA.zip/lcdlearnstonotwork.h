#include "i2c.h"
#include "hd44780_i2c.h"

void lcdHelloWorld(void);